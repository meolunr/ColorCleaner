MODULE_DIR=/data/adb/metamodule/mnt/colorcleaner
MODULE_DIR_PREFIX_COUNT=$(printf $MODULE_DIR | wc -c)

for i in $(find $MODULE_DIR/my_* -type f -not -name .replace); do
	mount -o bind "$i" "${i:$MODULE_DIR_PREFIX_COUNT}"
done
for i in $(find $MODULE_DIR/my_* -type f -name .replace); do
	local path=$(dirname "$i")
	mount -o bind "$path" "${path:$MODULE_DIR_PREFIX_COUNT}"
done